import React, { useEffect, useRef } from 'react';

/**
 * LinkPage React component
 * Props:
 * 